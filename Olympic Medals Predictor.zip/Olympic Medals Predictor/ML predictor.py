import pandas as pd

teams = pd.read_csv("teams.csv")  # Create a name for the dataset
teams = teams[  # Remove unwanted data values
    ["team", "country", "year", "athletes", "age", "prev_medals", "medals"]
]

teams.select_dtypes(include=["number"]).corr()[
    "medals"
]  # Find the correlation between the current medals won and the other data values

import seaborn as sns

sns.lmplot(
    x="athletes", y="medals", data=teams, fit_reg=True, ci=None
)  # Plot a graph of the correlation between the number atheles and medals won

teams[teams.isnull().any(axis=1)]  # Identify and remove missing information

teams = teams.dropna()

train = teams[
    teams["year"] < 2012
].copy()  # Split the data into a trainig set and a testing set
test = teams[teams["year"] >= 2012].copy()

# print(train.shape)     Check the size of the train and test sub-datasets
# print(test.shape)

from sklearn.linear_model import LinearRegression

reg = LinearRegression()

predictors = [
    "athletes",
    "prev_medals",
]  # Set data values the model will use to learn from and what value it will predict
target = "medals"

reg.fit(train[predictors], train["medals"])
LinearRegression()

predictions = reg.predict(test[predictors])  # Train the model on the dataset
test["predictions"] = (
    predictions  # Add the prediction values onto a seperate column in the csv file
)
test.loc[test["predictions"] < 0, "predictions"] = (
    0  # Set all the prediction values below zero to zero
)
test["predictions"] = test[
    "predictions"
].round()  # Round any non-integer values

from sklearn.metrics import mean_absolute_error

error = mean_absolute_error(
    test["medals"], test["predictions"]
)  # Calculate the absolute error

teams.describe()["medals"]  # Ensure our error is below the standard deviation

test[
    test["team"] == "USA"
]  # Check how far off the prediction is for an individual team

errors = (
    test["medals"] - test["predictions"]
).abs()  # Find the difference between actual and predicted medals
errors

error_by_team = errors.groupby(
    test["team"]
).mean()  # Get the average error per team
error_by_team

medals_by_team = (
    test["medals"].groupby(test["team"]).mean()
)  # Get the average medals won per team
error_ratio = (
    error_by_team / medals_by_team
)  # Get the ratio of average error / average medals won

import numpy as np  # Remove all NaN and Inf values

error_ratio[~pd.isnull(error_ratio)]
error_ratio = error_ratio[np.isfinite(error_ratio)]

print(test["predictions"])
